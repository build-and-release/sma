package com.technovate.school_management.repository;

import com.technovate.school_management.entity.FeeItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeeItemRepository extends JpaRepository<FeeItem, Long> {
}
