package com.technovate.school_management.entity.enums;

public enum GenderEnum {
    MALE,
    FEMALE
}
