package com.technovate.school_management.service.contracts;

import com.technovate.school_management.dto.CreateGuardianDto;

public interface GuardianService {
    void addGuardian(CreateGuardianDto createGuardianDto);
}
